'use client'

import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Music, BookOpen, GitCompare, Lightbulb } from 'lucide-react'

export default function Home() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <header className="py-20 px-4 text-center">
        <h1 className="text-4xl md:text-6xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-amber-400 to-rose-600">
          Turkish Makams & Minor Major 7 Arpeggios
        </h1>
        <p className="text-xl md:text-2xl text-slate-300 max-w-3xl mx-auto">
          Exploring the fascinating compatibility between Eastern modal systems and Western harmonic elements
        </p>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 pb-20">
        {/* Introduction */}
        <section className="mb-16">
          <p className="text-lg text-slate-300 mb-8">
            This website presents research on the compatibility between Turkish makams (modal scales) and Minor Major 7 arpeggios, 
            examining how these distinct musical elements can work together in composition and improvisation. By understanding the 
            intervallic structures, tonal characteristics, and expressive qualities of both systems, musicians can create unique 
            sonic landscapes that bridge Eastern and Western musical traditions.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Link href="/minor-major7">
              <Card className="p-6 h-full bg-slate-800 hover:bg-slate-700 transition-colors border-slate-700 cursor-pointer">
                <div className="flex flex-col items-center text-center h-full">
                  <Music className="h-12 w-12 mb-4 text-amber-400" />
                  <h3 className="text-xl font-semibold mb-2">Minor Major 7 Arpeggios</h3>
                  <p className="text-slate-300">Explore the structure, characteristics, and applications of these mysterious arpeggios</p>
                </div>
              </Card>
            </Link>
            
            <Link href="/turkish-makams">
              <Card className="p-6 h-full bg-slate-800 hover:bg-slate-700 transition-colors border-slate-700 cursor-pointer">
                <div className="flex flex-col items-center text-center h-full">
                  <BookOpen className="h-12 w-12 mb-4 text-amber-400" />
                  <h3 className="text-xl font-semibold mb-2">Turkish Makams</h3>
                  <p className="text-slate-300">Discover the rich tradition of Turkish modal scales and their unique characteristics</p>
                </div>
              </Card>
            </Link>
            
            <Link href="/compatibility">
              <Card className="p-6 h-full bg-slate-800 hover:bg-slate-700 transition-colors border-slate-700 cursor-pointer">
                <div className="flex flex-col items-center text-center h-full">
                  <GitCompare className="h-12 w-12 mb-4 text-amber-400" />
                  <h3 className="text-xl font-semibold mb-2">Compatibility Analysis</h3>
                  <p className="text-slate-300">Learn which Turkish makams work best with Minor Major 7 arpeggios and why</p>
                </div>
              </Card>
            </Link>
            
            <Link href="/applications">
              <Card className="p-6 h-full bg-slate-800 hover:bg-slate-700 transition-colors border-slate-700 cursor-pointer">
                <div className="flex flex-col items-center text-center h-full">
                  <Lightbulb className="h-12 w-12 mb-4 text-amber-400" />
                  <h3 className="text-xl font-semibold mb-2">Practical Applications</h3>
                  <p className="text-slate-300">Discover composition and improvisation techniques using these musical elements</p>
                </div>
              </Card>
            </Link>
          </div>
        </section>

        {/* Featured Content */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold mb-8 text-center">Key Findings</h2>
          
          <div className="bg-slate-800 border border-slate-700 rounded-lg p-6 mb-8">
            <h3 className="text-2xl font-semibold mb-4 text-amber-400">Most Compatible Turkish Makams</h3>
            <div className="space-y-4">
              <div>
                <h4 className="text-xl font-medium">Bûselik Makam - HIGHLY COMPATIBLE</h4>
                <p className="text-slate-300">
                  The Bûselik makam, especially in its second form with the Hicaz tetrachord, is identical to the A harmonic minor scale, 
                  making it exceptionally compatible with Minor Major 7 arpeggios. The G-sharp leading tone in Bûselik is precisely the 
                  major seventh needed for an AmM7 arpeggio.
                </p>
              </div>
              
              <div>
                <h4 className="text-xl font-medium">Hicaz Makam - HIGHLY COMPATIBLE</h4>
                <p className="text-slate-300">
                  The Hicaz makam contains a characteristic augmented second interval that creates tension similar to that found in 
                  Minor Major 7 arpeggios. The distinctive "Eastern" sound of Hicaz with its raised seventh degree works well with 
                  the tension of mM7 arpeggios.
                </p>
              </div>
            </div>
          </div>
          
          <div className="text-center">
            <Link href="/compatibility">
              <Button className="bg-amber-500 hover:bg-amber-600 text-black">
                Explore Full Compatibility Analysis
              </Button>
            </Link>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="py-8 border-t border-slate-700 text-center text-slate-400">
        <p>© 2025 Turkish Makams & Minor Major 7 Arpeggios Research</p>
      </footer>
    </div>
  )
}
