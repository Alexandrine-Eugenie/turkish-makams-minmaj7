'use client'

import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { ArrowLeft, BookOpen } from 'lucide-react'

export default function TurkishMakamsPage() {
  return (
    <div className="min-h-screen">
      {/* Navigation */}
      <nav className="p-4 border-b border-slate-700">
        <div className="max-w-6xl mx-auto">
          <Link href="/">
            <Button variant="ghost" className="text-slate-300 hover:text-white">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Home
            </Button>
          </Link>
        </div>
      </nav>

      {/* Header */}
      <header className="py-12 px-4 text-center">
        <BookOpen className="h-16 w-16 mx-auto mb-4 text-amber-400" />
        <h1 className="text-4xl font-bold mb-4">Turkish Makams</h1>
        <p className="text-xl text-slate-300 max-w-3xl mx-auto">
          Exploring the rich tradition of Turkish modal scales and their unique characteristics
        </p>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 pb-20">
        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-4 text-amber-400">Basic Structure and Characteristics</h2>
          <p className="text-lg text-slate-300 mb-6">
            Turkish makams are a complex system of melody types used in Turkish classical and folk music. Unlike Western scales, 
            makams are not just collections of notes but provide a comprehensive set of rules for composition and performance.
          </p>
          
          <div className="space-y-8">
            <div>
              <h3 className="text-xl font-semibold mb-3">Intervallic Structure</h3>
              <ul className="list-disc pl-6 text-slate-300 space-y-2">
                <li>The octave is divided into 53 equal intervals known as "commas" (Holdrian comma)</li>
                <li>Each whole tone equals 9 commas</li>
                <li>In practice, only 24 of the 53 commas are commonly used</li>
                <li>This allows for microtonal expressions not possible in Western equal temperament</li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-xl font-semibold mb-3">Melodic Development (Seyir)</h3>
              <p className="text-slate-300 mb-2">
                Each makam has a characteristic melodic progression called "seyir" (meaning "route"). Three types of seyir exist:
              </p>
              <ul className="list-disc pl-6 text-slate-300 space-y-2">
                <li>Ascending (çıkıcı)</li>
                <li>Descending (inici)</li>
                <li>Descending-ascending (inici-çıkıcı)</li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-xl font-semibold mb-3">Construction</h3>
              <ul className="list-disc pl-6 text-slate-300 space-y-2">
                <li>Makams are built by combining tetrachords (4-note groups) and pentachords (5-note groups)</li>
                <li>These combinations create the distinctive character of each makam</li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-xl font-semibold mb-3">Important Structural Notes</h3>
              <ul className="list-disc pl-6 text-slate-300 space-y-2">
                <li><strong>Durak (tonic):</strong> The initial note of the first tetrachord/pentachord; concludes pieces</li>
                <li><strong>Güçlü (dominant):</strong> The first note of the second tetrachord/pentachord; serves as temporary tonic</li>
                <li><strong>Yeden (leading tone):</strong> Often the penultimate note that resolves to the tonic</li>
              </ul>
            </div>
          </div>
        </section>

        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-6 text-amber-400">Notable Turkish Makams</h2>
          
          <div className="space-y-8">
            <div className="bg-slate-800 p-6 rounded-lg border border-slate-700">
              <h3 className="text-xl font-semibold mb-3">1. Bûselik Makam</h3>
              <ul className="list-disc pl-6 text-slate-300 space-y-2">
                <li>Similar to Western A minor</li>
                <li>First form: Bûselik pentachord + Kürdî tetrachord on Hüseyni (E)</li>
                <li>Second form: Bûselik pentachord + Hicaz tetrachord on Hüseyni (E), identical to A harmonic minor</li>
                <li>Tonic: A (Dügâh)</li>
                <li>Dominant: E (Hüseyni)</li>
                <li>Leading tone: G-sharp (Nim Zirgule)</li>
              </ul>
            </div>
            
            <div className="bg-slate-800 p-6 rounded-lg border border-slate-700">
              <h3 className="text-xl font-semibold mb-3">2. Hicaz Makam</h3>
              <ul className="list-disc pl-6 text-slate-300 space-y-2">
                <li>One of the most distinctive Turkish makams</li>
                <li>Contains the characteristic Hicaz tetrachord with its augmented second interval</li>
                <li>Similar to the Arabic Hijaz maqam</li>
                <li>Often used in religious music</li>
              </ul>
            </div>
            
            <div className="bg-slate-800 p-6 rounded-lg border border-slate-700">
              <h3 className="text-xl font-semibold mb-3">3. Kürdî Makam</h3>
              <ul className="list-disc pl-6 text-slate-300 space-y-2">
                <li>Features the Kürdî tetrachord</li>
                <li>Related to the Arabic Kurd maqam</li>
              </ul>
            </div>
            
            <div className="bg-slate-800 p-6 rounded-lg border border-slate-700">
              <h3 className="text-xl font-semibold mb-3">4. Rast Makam</h3>
              <ul className="list-disc pl-6 text-slate-300 space-y-2">
                <li>Considered to bring happiness and tranquility</li>
                <li>Consists of Rast pentachord + Rast tetrachord on Neva (D)</li>
                <li>Tonic: G (Rast)</li>
                <li>Dominant: D (Neva)</li>
                <li>When descending, the Bûselik tetrachord often replaces the Rast tetrachord</li>
                <li>Used in Turkish religious calls to prayer (ezan), particularly Ikindi and Yatsı</li>
              </ul>
            </div>
          </div>
        </section>

        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-4 text-amber-400">Relationship to Other Musical Traditions</h2>
          <p className="text-lg text-slate-300 mb-6">
            Turkish makams have relationships with other modal systems:
          </p>
          <ul className="list-disc pl-6 text-lg text-slate-300 mb-6 space-y-2">
            <li>Arabic maqams (24 equally spaced quarter-tones)</li>
            <li>Byzantine echos</li>
            <li>Central Asian Turkic music systems (Uyghur muqam, Uzbek shashmakom)</li>
            <li>Indian ragas</li>
          </ul>
          <p className="text-lg text-slate-300">
            In Turkish folk music, similar scales are called "Ayak" (Ayağı), which correspond to classical makams.
          </p>
        </section>

        <div className="flex justify-center space-x-4">
          <Link href="/minor-major7">
            <Button variant="outline" className="border-amber-500 text-amber-500 hover:bg-amber-500/10">
              Learn About Minor Major 7 Arpeggios
            </Button>
          </Link>
          <Link href="/compatibility">
            <Button className="bg-amber-500 hover:bg-amber-600 text-black">
              View Compatibility Analysis
            </Button>
          </Link>
        </div>
      </main>
    </div>
  )
}
