'use client'

import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { ArrowLeft, Music } from 'lucide-react'

export default function MinorMajor7Page() {
  return (
    <div className="min-h-screen">
      {/* Navigation */}
      <nav className="p-4 border-b border-slate-700">
        <div className="max-w-6xl mx-auto">
          <Link href="/">
            <Button variant="ghost" className="text-slate-300 hover:text-white">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Home
            </Button>
          </Link>
        </div>
      </nav>

      {/* Header */}
      <header className="py-12 px-4 text-center">
        <Music className="h-16 w-16 mx-auto mb-4 text-amber-400" />
        <h1 className="text-4xl font-bold mb-4">Minor Major 7 Arpeggios</h1>
        <p className="text-xl text-slate-300 max-w-3xl mx-auto">
          Understanding the structure, characteristics, and applications of these mysterious arpeggios
        </p>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 pb-20">
        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-4 text-amber-400">Structure and Intervals</h2>
          <p className="text-lg text-slate-300 mb-4">
            Minor Major 7 arpeggios (also written as minMaj7 or mM7) consist of four notes:
          </p>
          <ul className="list-disc pl-6 text-lg text-slate-300 mb-6 space-y-2">
            <li>Root (1)</li>
            <li>Minor third (♭3)</li>
            <li>Perfect fifth (5)</li>
            <li>Major seventh (7)</li>
          </ul>
          <p className="text-lg text-slate-300 mb-4">
            For example, an AmM7 arpeggio contains the notes: A - C - E - G♯
          </p>
          <p className="text-lg text-slate-300">
            In integer notation, the chord can be represented as {'{0, 3, 7, 11}'}.
          </p>
        </section>

        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-4 text-amber-400">Musical Characteristics</h2>
          <p className="text-lg text-slate-300 mb-4">
            Minor Major 7 arpeggios have a distinctive sound often described as:
          </p>
          <ul className="list-disc pl-6 text-lg text-slate-300 mb-6 space-y-2">
            <li>Mysterious</li>
            <li>Tense</li>
            <li>Unresolved</li>
            <li>Enigmatic</li>
          </ul>
          <p className="text-lg text-slate-300 mb-4">
            This unique character stems from the combination of a minor triad (which typically has a darker, more somber quality) 
            with a major seventh (which creates tension through its half-step relationship with the octave). The major seventh 
            functions as a leading tone, creating a pull toward the tonic that generates harmonic interest.
          </p>
        </section>

        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-4 text-amber-400">Theoretical Context</h2>
          <p className="text-lg text-slate-300 mb-4">
            Minor Major 7 arpeggios have important relationships with several scales:
          </p>
          <ul className="list-disc pl-6 text-lg text-slate-300 mb-6 space-y-2">
            <li>They relate to the tonic minor chord of both the melodic minor and harmonic minor scales</li>
            <li>The chord occurs on the tonic (I) when harmonizing the harmonic minor scale in seventh chords</li>
            <li>They can also be associated with the IV chord of the harmonic major scale</li>
          </ul>
        </section>

        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-4 text-amber-400">Musical Applications</h2>
          <p className="text-lg text-slate-300 mb-4">
            These arpeggios appear across various musical traditions:
          </p>
          
          <div className="space-y-6">
            <div>
              <h3 className="text-xl font-semibold mb-2">Classical Music</h3>
              <p className="text-slate-300">
                Used more in the Romantic period than in Classical and Baroque periods.
                Notable example: Final bar of Bach's St Matthew Passion.
              </p>
            </div>
            
            <div>
              <h3 className="text-xl font-semibold mb-2">Jazz</h3>
              <p className="text-slate-300">
                Often used as a minor tonic. Improvisations typically use melodic minor or harmonic minor scales over this chord.
              </p>
            </div>
            
            <div>
              <h3 className="text-xl font-semibold mb-2">Film Music</h3>
              <p className="text-slate-300">
                Bernard Herrmann's use in Hitchcock films (especially Psycho) earned it the nickname "The Hitchcock Chord".
              </p>
            </div>
            
            <div>
              <h3 className="text-xl font-semibold mb-2">Flamenco</h3>
              <p className="text-slate-300">
                Used as an abstract chord to create atmosphere with a Moorish feel.
              </p>
            </div>
            
            <div>
              <h3 className="text-xl font-semibold mb-2">Rock/Popular Music</h3>
              <p className="text-slate-300">
                Infrequent, but examples include songs by The Beatles, Pink Floyd, Radiohead, and others.
              </p>
            </div>
          </div>
        </section>

        <div className="flex justify-center space-x-4">
          <Link href="/turkish-makams">
            <Button className="bg-amber-500 hover:bg-amber-600 text-black">
              Explore Turkish Makams
            </Button>
          </Link>
          <Link href="/compatibility">
            <Button variant="outline" className="border-amber-500 text-amber-500 hover:bg-amber-500/10">
              View Compatibility Analysis
            </Button>
          </Link>
        </div>
      </main>
    </div>
  )
}
