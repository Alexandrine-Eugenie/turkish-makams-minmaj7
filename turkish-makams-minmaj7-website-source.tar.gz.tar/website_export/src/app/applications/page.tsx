'use client'

import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { ArrowLeft, Lightbulb } from 'lucide-react'

export default function ApplicationsPage() {
  return (
    <div className="min-h-screen">
      {/* Navigation */}
      <nav className="p-4 border-b border-slate-700">
        <div className="max-w-6xl mx-auto">
          <Link href="/">
            <Button variant="ghost" className="text-slate-300 hover:text-white">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Home
            </Button>
          </Link>
        </div>
      </nav>

      {/* Header */}
      <header className="py-12 px-4 text-center">
        <Lightbulb className="h-16 w-16 mx-auto mb-4 text-amber-400" />
        <h1 className="text-4xl font-bold mb-4">Practical Applications</h1>
        <p className="text-xl text-slate-300 max-w-3xl mx-auto">
          Discover composition and improvisation techniques using Turkish makams and Minor Major 7 arpeggios
        </p>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 pb-20">
        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-6 text-amber-400">Composition Techniques</h2>
          
          <div className="space-y-8">
            <div className="bg-slate-800 p-6 rounded-lg border border-slate-700">
              <h3 className="text-xl font-semibold mb-3">1. Harmonic Anchoring</h3>
              <p className="text-slate-300 mb-4">
                Use mM7 arpeggios as harmonic anchors in pieces based on compatible Turkish makams.
              </p>
              <div className="space-y-2">
                <p className="text-slate-300"><strong>Example:</strong></p>
                <ul className="list-disc pl-6 text-slate-300 space-y-2">
                  <li>Create a piece in Bûselik makam with AmM7 arpeggios as harmonic foundations</li>
                  <li>Place the mM7 arpeggio at key structural points (beginning, climax, end)</li>
                  <li>Use the arpeggio to establish the tonal center before exploring the full makam</li>
                </ul>
              </div>
            </div>
            
            <div className="bg-slate-800 p-6 rounded-lg border border-slate-700">
              <h3 className="text-xl font-semibold mb-3">2. Modal Interchange</h3>
              <p className="text-slate-300 mb-4">
                Create compositions that move between different makams while maintaining the mM7 arpeggio as a common element.
              </p>
              <div className="space-y-2">
                <p className="text-slate-300"><strong>Example:</strong></p>
                <ul className="list-disc pl-6 text-slate-300 space-y-2">
                  <li>Begin in Bûselik makam with AmM7 arpeggios</li>
                  <li>Transition to Hicaz makam while maintaining the mM7 arpeggio structure</li>
                  <li>Use the common tones between the makams to create smooth transitions</li>
                </ul>
              </div>
            </div>
            
            <div className="bg-slate-800 p-6 rounded-lg border border-slate-700">
              <h3 className="text-xl font-semibold mb-3">3. Tension and Resolution</h3>
              <p className="text-slate-300 mb-4">
                Exploit the inherent tension in both mM7 arpeggios and certain makams to create dramatic musical narratives.
              </p>
              <div className="space-y-2">
                <p className="text-slate-300"><strong>Example:</strong></p>
                <ul className="list-disc pl-6 text-slate-300 space-y-2">
                  <li>Use the tension between the minor triad and major seventh in mM7 arpeggios</li>
                  <li>Pair with the augmented second interval in Hicaz makam</li>
                  <li>Create resolution points where these tensions are released</li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-6 text-amber-400">Improvisation Techniques</h2>
          
          <div className="space-y-8">
            <div className="bg-slate-800 p-6 rounded-lg border border-slate-700">
              <h3 className="text-xl font-semibold mb-3">1. Target Note Approach</h3>
              <p className="text-slate-300 mb-4">
                Use notes from mM7 arpeggios as target points in makam-based improvisations.
              </p>
              <div className="space-y-2">
                <p className="text-slate-300"><strong>Example:</strong></p>
                <ul className="list-disc pl-6 text-slate-300 space-y-2">
                  <li>In Bûselik makam, emphasize the G# (major seventh) at key moments</li>
                  <li>Create melodic lines that lead to and from the arpeggio tones</li>
                  <li>Use the traditional seyir (melodic progression) of the makam to approach these target notes</li>
                </ul>
              </div>
            </div>
            
            <div className="bg-slate-800 p-6 rounded-lg border border-slate-700">
              <h3 className="text-xl font-semibold mb-3">2. Rhythmic Displacement</h3>
              <p className="text-slate-300 mb-4">
                Explore different rhythmic placements of mM7 arpeggios within makam-based phrases.
              </p>
              <div className="space-y-2">
                <p className="text-slate-300"><strong>Example:</strong></p>
                <ul className="list-disc pl-6 text-slate-300 space-y-2">
                  <li>Play mM7 arpeggios starting on different beats of the measure</li>
                  <li>Combine with traditional Turkish rhythmic patterns (usuls)</li>
                  <li>Create polyrhythmic effects by placing the arpeggio against the underlying rhythmic structure</li>
                </ul>
              </div>
            </div>
            
            <div className="bg-slate-800 p-6 rounded-lg border border-slate-700">
              <h3 className="text-xl font-semibold mb-3">3. Ornamental Integration</h3>
              <p className="text-slate-300 mb-4">
                Incorporate traditional Turkish ornaments into mM7 arpeggio patterns.
              </p>
              <div className="space-y-2">
                <p className="text-slate-300"><strong>Example:</strong></p>
                <ul className="list-disc pl-6 text-slate-300 space-y-2">
                  <li>Add çarpma (grace notes) to arpeggio tones</li>
                  <li>Use vibrato (titreşim) on sustained notes of the arpeggio</li>
                  <li>Incorporate glissando (kaydırma) between arpeggio tones</li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-6 text-amber-400">Instrumentation Considerations</h2>
          
          <div className="space-y-6">
            <p className="text-lg text-slate-300">
              The choice of instruments significantly impacts how effectively Turkish makams and mM7 arpeggios can be combined:
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-slate-800 p-6 rounded-lg border border-slate-700 h-full">
                <h3 className="text-xl font-semibold mb-3">Ideal Instruments</h3>
                <ul className="list-disc pl-6 text-slate-300 space-y-2">
                  <li>
                    <strong>Fretless String Instruments:</strong> Oud, fretless guitar, violin, cello
                    <p className="text-sm text-slate-400 mt-1">
                      These can accurately produce both the precise intervals of mM7 arpeggios and the microtonal nuances of makams
                    </p>
                  </li>
                  <li>
                    <strong>Wind Instruments:</strong> Ney, clarinet, saxophone
                    <p className="text-sm text-slate-400 mt-1">
                      Capable of producing microtones through embouchure adjustments
                    </p>
                  </li>
                  <li>
                    <strong>Voice:</strong> The human voice is exceptionally well-suited for this fusion
                    <p className="text-sm text-slate-400 mt-1">
                      Can navigate both systems with appropriate training
                    </p>
                  </li>
                </ul>
              </div>
              
              <div className="bg-slate-800 p-6 rounded-lg border border-slate-700 h-full">
                <h3 className="text-xl font-semibold mb-3">Challenging Instruments</h3>
                <ul className="list-disc pl-6 text-slate-300 space-y-2">
                  <li>
                    <strong>Fixed-Pitch Instruments:</strong> Piano, standard guitar, vibraphone
                    <p className="text-sm text-slate-400 mt-1">
                      Limited in their ability to produce the microtones essential to Turkish makams
                    </p>
                  </li>
                  <li>
                    <strong>Workarounds:</strong>
                    <p className="text-sm text-slate-400 mt-1">
                      Use these instruments for the mM7 arpeggios while other instruments handle the makam's microtonal aspects
                    </p>
                  </li>
                  <li>
                    <strong>Alternative Tunings:</strong>
                    <p className="text-sm text-slate-400 mt-1">
                      Explore quarter-tone pianos or specially tuned guitars for more authentic makam sounds
                    </p>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-6 text-amber-400">Recording and Production Tips</h2>
          
          <div className="bg-slate-800 p-6 rounded-lg border border-slate-700">
            <ul className="list-disc pl-6 text-slate-300 space-y-3">
              <li>
                <strong>Spatial Arrangement:</strong> Use stereo field to separate makam elements from mM7 arpeggio elements
              </li>
              <li>
                <strong>Reverb Choices:</strong> Apply different reverb characteristics to enhance the distinct qualities of each musical system
              </li>
              <li>
                <strong>EQ Considerations:</strong> Highlight the microtonal aspects of makams with careful equalization
              </li>
              <li>
                <strong>Dynamic Processing:</strong> Use compression to balance the potentially different dynamic ranges of these musical elements
              </li>
            </ul>
          </div>
        </section>

        <div className="flex justify-center space-x-4">
          <Link href="/compatibility">
            <Button variant="outline" className="border-amber-500 text-amber-500 hover:bg-amber-500/10">
              View Compatibility Analysis
            </Button>
          </Link>
          <Link href="/">
            <Button className="bg-amber-500 hover:bg-amber-600 text-black">
              Return to Home
            </Button>
          </Link>
        </div>
      </main>
    </div>
  )
}
