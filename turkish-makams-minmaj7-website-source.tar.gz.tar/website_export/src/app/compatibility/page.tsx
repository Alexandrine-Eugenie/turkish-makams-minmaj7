'use client'

import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { ArrowLeft, GitCompare } from 'lucide-react'

export default function CompatibilityPage() {
  return (
    <div className="min-h-screen">
      {/* Navigation */}
      <nav className="p-4 border-b border-slate-700">
        <div className="max-w-6xl mx-auto">
          <Link href="/">
            <Button variant="ghost" className="text-slate-300 hover:text-white">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Home
            </Button>
          </Link>
        </div>
      </nav>

      {/* Header */}
      <header className="py-12 px-4 text-center">
        <GitCompare className="h-16 w-16 mx-auto mb-4 text-amber-400" />
        <h1 className="text-4xl font-bold mb-4">Compatibility Analysis</h1>
        <p className="text-xl text-slate-300 max-w-3xl mx-auto">
          Exploring which Turkish makams work best with Minor Major 7 arpeggios and why
        </p>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 pb-20">
        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-6 text-amber-400">Compatibility Overview</h2>
          <p className="text-lg text-slate-300 mb-6">
            The compatibility between Turkish makams and Minor Major 7 arpeggios depends on several factors, including 
            intervallic structure, tonal characteristics, and the presence of specific notes that create tension or resolution. 
            After thorough analysis, we've identified which makams work particularly well with mM7 arpeggios.
          </p>
          
          <div className="bg-slate-800 p-6 rounded-lg border border-slate-700 mb-8">
            <h3 className="text-xl font-semibold mb-4">Compatibility Factors</h3>
            <ul className="list-disc pl-6 text-slate-300 space-y-3">
              <li>
                <strong>Intervallic Structure:</strong> Makams with intervals that align with the mM7 arpeggio structure 
                (root, minor third, perfect fifth, major seventh) tend to be more compatible.
              </li>
              <li>
                <strong>Tension and Resolution:</strong> Both systems feature similar tension points - the minor/major contrast 
                in mM7 arpeggios creates a tension similar to the characteristic intervals in certain makams.
              </li>
              <li>
                <strong>Theoretical Context:</strong> Minor Major 7 arpeggios relate to the tonic minor chord of both the 
                melodic minor and harmonic minor scales, which have structural similarities to certain Turkish makams.
              </li>
              <li>
                <strong>Leading Tone Presence:</strong> Makams that naturally include a leading tone (major seventh) are 
                particularly compatible with mM7 arpeggios.
              </li>
            </ul>
          </div>
        </section>

        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-6 text-amber-400">Highly Compatible Makams</h2>
          
          <div className="space-y-8">
            <div className="bg-gradient-to-r from-amber-500/20 to-rose-500/20 p-6 rounded-lg border border-amber-500/30">
              <h3 className="text-xl font-semibold mb-3">1. Bûselik Makam - HIGHLY COMPATIBLE</h3>
              <p className="text-slate-300 mb-4">
                The Bûselik makam, especially in its second form with the Hicaz tetrachord, is identical to the A harmonic 
                minor scale, making it exceptionally compatible with Minor Major 7 arpeggios.
              </p>
              <div className="space-y-2">
                <p className="text-slate-300"><strong>Why it works:</strong></p>
                <ul className="list-disc pl-6 text-slate-300 space-y-1">
                  <li>When an AmM7 arpeggio (A-C-E-G♯) is built on the tonic of Bûselik makam, all notes align perfectly with the makam's structure</li>
                  <li>The G-sharp leading tone (yeden) in Bûselik is precisely the major seventh needed for an AmM7 arpeggio</li>
                  <li>The minor tetrachord at the bottom of the scale aligns with the minor triad portion of the mM7 arpeggio</li>
                </ul>
              </div>
            </div>
            
            <div className="bg-gradient-to-r from-amber-500/20 to-rose-500/20 p-6 rounded-lg border border-amber-500/30">
              <h3 className="text-xl font-semibold mb-3">2. Hicaz Makam - HIGHLY COMPATIBLE</h3>
              <p className="text-slate-300 mb-4">
                The Hicaz makam contains a characteristic augmented second interval that creates tension similar to that 
                found in Minor Major 7 arpeggios.
              </p>
              <div className="space-y-2">
                <p className="text-slate-300"><strong>Why it works:</strong></p>
                <ul className="list-disc pl-6 text-slate-300 space-y-1">
                  <li>The distinctive "Eastern" sound of Hicaz with its raised seventh degree works well with the tension of mM7 arpeggios</li>
                  <li>DmM7 arpeggios would work particularly well in Hicaz makam on D</li>
                  <li>The augmented second interval in Hicaz creates a similar tension to the minor/major contrast in mM7 arpeggios</li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-6 text-amber-400">Moderately Compatible Makams</h2>
          
          <div className="space-y-8">
            <div className="bg-slate-800 p-6 rounded-lg border border-slate-700">
              <h3 className="text-xl font-semibold mb-3">3. Kürdî Makam - MODERATELY COMPATIBLE</h3>
              <p className="text-slate-300 mb-4">
                The Kürdî makam features minor tetrachords that can accommodate Minor Major 7 arpeggios with some adjustments.
              </p>
              <div className="space-y-2">
                <p className="text-slate-300"><strong>Why it works with modifications:</strong></p>
                <ul className="list-disc pl-6 text-slate-300 space-y-1">
                  <li>While Kürdî doesn't naturally emphasize the major seventh that gives mM7 its distinctive character, it can still work with careful placement</li>
                  <li>The minor tetrachord aligns with the minor triad portion of the mM7 arpeggio</li>
                  <li>Requires more deliberate voice leading to integrate the major seventh effectively</li>
                </ul>
              </div>
            </div>
            
            <div className="bg-slate-800 p-6 rounded-lg border border-slate-700">
              <h3 className="text-xl font-semibold mb-3">4. Uşşâk Makam - MODERATELY COMPATIBLE</h3>
              <p className="text-slate-300 mb-4">
                Similar to Kürdî, the Uşşâk makam can work with Minor Major 7 arpeggios but requires more careful integration.
              </p>
              <div className="space-y-2">
                <p className="text-slate-300"><strong>Why it works with modifications:</strong></p>
                <ul className="list-disc pl-6 text-slate-300 space-y-1">
                  <li>The Uşşâk tetrachord provides a minor-like quality that aligns with the minor triad portion of mM7</li>
                  <li>The major seventh must be deliberately introduced as it's not a natural part of the makam</li>
                  <li>Works best when the mM7 arpeggio is used as a passing or transitional element rather than a central harmonic focus</li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-6 text-amber-400">Practical Examples</h2>
          
          <div className="space-y-6">
            <div>
              <h3 className="text-xl font-semibold mb-3">Example 1: Bûselik Makam with AmM7</h3>
              <p className="text-slate-300 mb-2">
                A composition in Bûselik makam could use AmM7 arpeggios (A-C-E-G♯) as follows:
              </p>
              <ul className="list-disc pl-6 text-slate-300 space-y-2">
                <li>Use the arpeggio as a harmonic foundation at key structural points</li>
                <li>Emphasize the G♯ (major seventh) at cadential points to highlight the distinctive character</li>
                <li>Alternate between AmM7 and Am7 arpeggios to create tension and release</li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-xl font-semibold mb-3">Example 2: Hicaz Makam with DmM7</h3>
              <p className="text-slate-300 mb-2">
                A composition in Hicaz makam on D could incorporate DmM7 arpeggios (D-F-A-C♯) by:
              </p>
              <ul className="list-disc pl-6 text-slate-300 space-y-2">
                <li>Using the arpeggio to emphasize the characteristic augmented second interval of Hicaz</li>
                <li>Creating melodic lines that outline the arpeggio while following the traditional seyir (melodic progression) of Hicaz</li>
                <li>Using the C♯ (major seventh) to create tension that resolves to the tonic D</li>
              </ul>
            </div>
          </div>
        </section>

        <div className="flex justify-center space-x-4">
          <Link href="/turkish-makams">
            <Button variant="outline" className="border-amber-500 text-amber-500 hover:bg-amber-500/10">
              Learn About Turkish Makams
            </Button>
          </Link>
          <Link href="/applications">
            <Button className="bg-amber-500 hover:bg-amber-600 text-black">
              Explore Practical Applications
            </Button>
          </Link>
        </div>
      </main>
    </div>
  )
}
